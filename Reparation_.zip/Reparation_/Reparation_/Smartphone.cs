﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Smartphone : Form
    {
        public Smartphone()
        {
            InitializeComponent();
        }
        string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                if ((string.IsNullOrWhiteSpace(telClient.Text) || (string.IsNullOrWhiteSpace(nomClient.Text)) || ((string.IsNullOrWhiteSpace(AmntDiagno.Text)))))
                {
                    MessageBox.Show("Please fill the compulsary textbox (*)!!!");
                }
               else
                {
                    string Nom_client = nomClient.Text;
                    string tel_Client = telClient.Text;
                    DateTime Rendez_Vous = RDB.Value;
                    string Marque_telephone = marque.Text;
                    string Numero_serie = Nserie.Text;
                    string pieces_Deposeer = piecesDeposer.Text;
                    string Panne_telephone = panne.Text;
                    double Montant_Diagnostics = double.Parse(AmntDiagno.Text);

                    string strRequete = "INSERT INTO TP_Reparation" +
                        "(Numero,Nom_Client,Telephone_Client,Marque_Smartphone,Numero_Serie,Date_Rendez_Vous,Panne,Montant_Diagnostic,Pieces_Deposer,Date_Entree,Etat)" +
                        "VALUES (@Numero,@Nom_Client,@Telephone_Client,@Marque_Smartphone,@Numero_Serie,@Date_Rendez_Vous,@Panne,@Montant_Diagnostic,@Pieces_Deposer,@Date_Entree,@Etat)";

                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                    oCommand.Parameters.AddWithValue("@Numero", GetMatricule());
                    oCommand.Parameters.AddWithValue("@Nom_Client", Nom_client);
                    oCommand.Parameters.AddWithValue("@Telephone_Client", tel_Client);
                    oCommand.Parameters.AddWithValue("@Marque_Smartphone", Marque_telephone);
                    oCommand.Parameters.AddWithValue("@Numero_Serie", Numero_serie);
                    oCommand.Parameters.AddWithValue("@Date_Rendez_Vous", Rendez_Vous);
                    oCommand.Parameters.AddWithValue("@Panne", Panne_telephone);
                    oCommand.Parameters.AddWithValue("@Montant_Diagnostic", Montant_Diagnostics);
                    oCommand.Parameters.AddWithValue("@Pieces_Deposer", pieces_Deposeer);
                    oCommand.Parameters.AddWithValue("@Date_Entree", DateTime.Now);
                    oCommand.Parameters.AddWithValue("@Etat", 0);
                    MessageBox.Show("New Smartphone Saved. Please Load your table!!!");
                    nomClient.Text = null;
                    telClient.Text = null;
                    RDB.Text = null;
                    marque.Text = null;
                    Nserie.Text = null;
                    piecesDeposer.Text = null;
                    panne.Text = null;
                    AmntDiagno.Text = null;
                    oConnection.Open();
                    oCommand.ExecuteNonQuery();
                    oConnection.Close();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("CONNECTION ERROR :" + ex.Message);
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            nomClient.Text = null;
            telClient.Text = null;
            RDB.Text = null;
            marque.Text = null;
            Nserie.Text = null;
            piecesDeposer.Text = null;
            panne.Text = null;
            AmntDiagno.Text = null;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Dispose();
        }
        private void Smartphone_Load(object sender, EventArgs e)
        {
            ActiveControl = nomClient;  // for the cursor to fucus
        }

        private void telClient_TextChanged(object sender, EventArgs e)
        {
            // ensuring that the entered value is a number
            {
                string tString = telClient.Text;
                if (tString.Trim() == "") return;
                for (int i = 0; i < tString.Length; i++)
                {
                    if (!char.IsNumber(tString[i]))
                    {
                        MessageBox.Show("Please enter a valid number 'XXXXXXXXXXXXXX'");
                        telClient.Text = "";
                        return;
                    }
                }
            }
        }
        public string GetMatricule()// Function to automatically generate matricule
        {
            string Matricular = "CT_No-";
            string strRequete = "SELECT Count(*) as nombre FROM TP_Reparation";
            string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
            int nbre = 0;
            SqlConnection oConnection = new SqlConnection(strConnexion);
            SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
            oConnection.Open();
            SqlDataReader oReader = oCommand.ExecuteReader();
            if (oReader.Read())
            {
                nbre = oReader.GetInt32(0);
            }
            Matricular = "CT_No-" + (++nbre).ToString();
            oReader.Close();
            oConnection.Close();
            return Matricular;
        }
        private void AmntDiagno_TextChanged(object sender, EventArgs e)
        {
            {
                string tString = AmntDiagno.Text;
                if (tString.Trim() == "") return;
                for (int i = 0; i < tString.Length; i++)
                {
                    if (!char.IsNumber(tString[i]))
                    {
                        MessageBox.Show("Please enter a valid number");
                        AmntDiagno.Text = "";
                        return;
                    }
                }
            }
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }



        /*
         *this function is to set an automatic id conter on a textbox





         */
        //public void IDFunction()
        //{
        //    string strRequete = "SELECT MAX(Numero)+1 FROM TP_Reparation";
        //    string Matricular = "CT";

        //    SqlConnection oConnection = new SqlConnection(strConnexion);
        //     oConnection.Open();
        //    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
        //    SqlDataReader dr = oCommand.ExecuteReader();

        //    if (dr.HasRows)
        //    {
        //        while (dr.Read())
        //        {
        //            NumeroClient.Text = dr[0].ToString();
        //            if (NumeroClient.Text == "")
        //            {
        //                NumeroClient.Text = "1"+ "CT";
        //            }
        //        }
        //    }
        //    else
        //    {
        //        NumeroClient.Text = "1" + "CT";
        //    }
        //    oConnection.Close();
        //}

    }
}

