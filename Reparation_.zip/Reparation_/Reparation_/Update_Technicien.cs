﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Update_Technicien : Form
    {
        private int id;
        public Update_Technicien(int id)
        {
            InitializeComponent();
            this.id = id;
        }
        private void updateBtn_Click(object sender, EventArgs e)
        {
            try
            {

                string Matricule_tech = matricule.Text;
                string Nom_tech = nom.Text;
                string tel_tech = telephone.Text;
                string adress_tech = adresse.Text;
                string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
                string strRequete = "UPDATE TP_Technicien SET Matricule = @Matricule, Nom = @Nom, Telephone = @Telephone, Adresse = @Adresse WHERE ID_Techinicien =  " + id.ToString();

                SqlConnection oConnection = new SqlConnection(strConnexion);
                SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                oCommand.Parameters.AddWithValue("@Matricule", Matricule_tech);
                oCommand.Parameters.AddWithValue("@Nom", Nom_tech);
                oCommand.Parameters.AddWithValue("@Telephone", tel_tech);
                oCommand.Parameters.AddWithValue("@Adresse", adress_tech);
                //oCommand.Parameters.AddWithValue("@ID_Techinicien", id);

               
                
                this.Dispose();
                oConnection.Open();
                oCommand.ExecuteNonQuery();
                oConnection.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine("CONNECTION ERROR :" + ex.Message);
            }
            EmptyTextBox();
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            matricule.Text = null;
            telephone.Text = null;
            nom.Text = null;
            adresse.Text = null;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }
        public void EmptyTextBox()
        {
            matricule.Text = null;
            telephone.Text = null;
            nom.Text = null;
            adresse.Text = null;
        }

        private void matricule_TextChanged(object sender, EventArgs e)
        {

        }

        private void telephone_TextChanged(object sender, EventArgs e)
        {
            {
                string tString = telephone.Text;
                if (tString.Trim() == "") return;
                for (int i = 0; i < tString.Length; i++)
                {
                    if (!char.IsNumber(tString[i]))
                    {
                        MessageBox.Show("Please enter a valid number");
                        telephone.Text = "";
                        return;
                    }
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
        //public void IDFunction()
        //{
        //    string strRequete = "SELECT MAX(Numero)+1 FROM TP_Reparation";
        //    string Matricular = "CT";
        //    string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
        //    SqlConnection oConnection = new SqlConnection(strConnexion);
        //    oConnection.Open();
        //    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
        //    SqlDataReader dr = oCommand.ExecuteReader();

        //    if (dr.HasRows)
        //    {
        //        while (dr.Read())
        //        {
        //            matricule.Text = dr[0].ToString();
        //            if (matricule.Text == "")
        //            {
        //                matricule.Text = "1" + "CT";
        //            }
        //        }
        //    }
        //    else
        //    {
        //        matricule.Text = "1" + "CT";
        //    }
        //    oConnection.Close();
        //}

    }
}
