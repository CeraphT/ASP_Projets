﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Form1 : Form
    {
        string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";       
        public Form1()
        {
            InitializeComponent();
           
        }
        private void button2_Click(object sender, EventArgs e)
        {
            string numero = telephone.Text;
            if ((string.IsNullOrWhiteSpace(nom.Text)) && (string.IsNullOrWhiteSpace(telephone.Text)))
            {
                MessageBox.Show("Please fill the compulsary textbox (*)!!!");
            }
            else if (telephone.Text != numero)
            {
                MessageBox.Show("Please enter a correct telephone number!");
                }
            else
            {
                //string Matricule = matricule.Text;
                string Nom = nom.Text;
                string Adresse = adresse.Text;
                string Telephone = telephone.Text;
                string strRequete = "INSERT INTO TP_Technicien VALUES (@matricule,@nom,@telephone,@adresse)";



                try
                {
                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                    oCommand.Parameters.AddWithValue("@matricule", GetMatricule());
                    oCommand.Parameters.AddWithValue("@nom", Nom);
                    oCommand.Parameters.AddWithValue("@telephone", Telephone);
                    oCommand.Parameters.AddWithValue("@adresse", Adresse);
                    MessageBox.Show("New Technicien Created. Please load your table!!!");
                    oConnection.Open();
                    oCommand.ExecuteNonQuery();
                    oConnection.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("CONNECTION ERROR :" + ex.Message);
                }
                ClearFunction();
            }
           
            
        }     
        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
        private void ClearBtn_Click(object sender, EventArgs e)
        {
          //  matricule.Text = null;
            nom.Text = null;
            telephone.Text = null;
            adresse.Text = null;
        }
        public void ClearFunction()
        {

           // matricule.Text = null;
            nom.Text = null;
            telephone.Text = null;
            adresse.Text = null;
        }

        private void matricule_TextChanged(object sender, EventArgs e)
        {
            
        }
        public string GetMatricule()
        {
            string Matricular = "CT";
            string strRequete = "SELECT Count(*) as nombre FROM TP_Technicien";
            string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
            //string strRequete = "SELECT * FROM TP_Technicien where ID_Techinicien = " + id;
            int nbre = 0;
            SqlConnection oConnection = new SqlConnection(strConnexion);
            SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
            oConnection.Open();
            SqlDataReader oReader = oCommand.ExecuteReader();
            if (oReader.Read())
            {
                nbre = oReader.GetInt32(0);
                
            }
            Matricular = "CT-" + (++nbre).ToString();
            oReader.Close();
            oConnection.Close();
            return Matricular;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.ActiveControl = nom;
        }

        private void telephone_TextChanged(object sender, EventArgs e)
        {
            {
                string tString = telephone.Text;
                if (tString.Trim() == "") return;
                for (int i = 0; i < tString.Length; i++)
                {
                    if (!char.IsNumber(tString[i]))
                    {
                        MessageBox.Show("Please enter a valid number 'XXXXXXXXXXXXXX'");
                        telephone.Text = "";
                        return;
                    }
                }
            }
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
