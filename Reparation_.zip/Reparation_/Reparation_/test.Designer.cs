﻿namespace Reparation_
{
    partial class test
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDiagnoAmount = new System.Windows.Forms.TextBox();
            this.txtChangedItems = new System.Windows.Forms.TextBox();
            this.txtEntryDate = new System.Windows.Forms.TextBox();
            this.txtClientPhone = new System.Windows.Forms.TextBox();
            this.txtExitDate = new System.Windows.Forms.TextBox();
            this.txtRDVDate = new System.Windows.Forms.TextBox();
            this.txtSmartphoneMark = new System.Windows.Forms.TextBox();
            this.txtClientNumber = new System.Windows.Forms.TextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.txtTechMatricul = new System.Windows.Forms.TextBox();
            this.txtTechName = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtTechRepport = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txtHandWork = new System.Windows.Forms.TextBox();
            this.txtChangedItemAmt = new System.Windows.Forms.TextBox();
            this.txtPhoneTrouble = new System.Windows.Forms.TextBox();
            this.txtDepositedItems = new System.Windows.Forms.TextBox();
            this.txtPhoneState = new System.Windows.Forms.TextBox();
            this.txtClientAddress = new System.Windows.Forms.TextBox();
            this.button1 = new System.Windows.Forms.Button();
            this.txtSerialNumber = new System.Windows.Forms.TextBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.label15 = new System.Windows.Forms.Label();
            this.label22 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.txtClientNmae = new System.Windows.Forms.TextBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel3.SuspendLayout();
            this.panel4.SuspendLayout();
            this.panel2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtDiagnoAmount
            // 
            this.txtDiagnoAmount.Location = new System.Drawing.Point(587, 260);
            this.txtDiagnoAmount.Name = "txtDiagnoAmount";
            this.txtDiagnoAmount.ReadOnly = true;
            this.txtDiagnoAmount.Size = new System.Drawing.Size(209, 20);
            this.txtDiagnoAmount.TabIndex = 1;
            // 
            // txtChangedItems
            // 
            this.txtChangedItems.Location = new System.Drawing.Point(997, 96);
            this.txtChangedItems.Multiline = true;
            this.txtChangedItems.Name = "txtChangedItems";
            this.txtChangedItems.ReadOnly = true;
            this.txtChangedItems.Size = new System.Drawing.Size(209, 39);
            this.txtChangedItems.TabIndex = 1;
            // 
            // txtEntryDate
            // 
            this.txtEntryDate.Location = new System.Drawing.Point(587, 117);
            this.txtEntryDate.Name = "txtEntryDate";
            this.txtEntryDate.ReadOnly = true;
            this.txtEntryDate.Size = new System.Drawing.Size(209, 20);
            this.txtEntryDate.TabIndex = 1;
            // 
            // txtClientPhone
            // 
            this.txtClientPhone.Location = new System.Drawing.Point(173, 260);
            this.txtClientPhone.Name = "txtClientPhone";
            this.txtClientPhone.ReadOnly = true;
            this.txtClientPhone.Size = new System.Drawing.Size(209, 20);
            this.txtClientPhone.TabIndex = 1;
            // 
            // txtExitDate
            // 
            this.txtExitDate.Location = new System.Drawing.Point(997, 220);
            this.txtExitDate.Name = "txtExitDate";
            this.txtExitDate.ReadOnly = true;
            this.txtExitDate.Size = new System.Drawing.Size(209, 20);
            this.txtExitDate.TabIndex = 1;
            // 
            // txtRDVDate
            // 
            this.txtRDVDate.Location = new System.Drawing.Point(587, 184);
            this.txtRDVDate.Name = "txtRDVDate";
            this.txtRDVDate.ReadOnly = true;
            this.txtRDVDate.Size = new System.Drawing.Size(209, 20);
            this.txtRDVDate.TabIndex = 1;
            // 
            // txtSmartphoneMark
            // 
            this.txtSmartphoneMark.Location = new System.Drawing.Point(587, 44);
            this.txtSmartphoneMark.Name = "txtSmartphoneMark";
            this.txtSmartphoneMark.ReadOnly = true;
            this.txtSmartphoneMark.Size = new System.Drawing.Size(209, 20);
            this.txtSmartphoneMark.TabIndex = 1;
            // 
            // txtClientNumber
            // 
            this.txtClientNumber.Location = new System.Drawing.Point(173, 184);
            this.txtClientNumber.Name = "txtClientNumber";
            this.txtClientNumber.ReadOnly = true;
            this.txtClientNumber.Size = new System.Drawing.Size(209, 20);
            this.txtClientNumber.TabIndex = 1;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.SystemColors.ButtonShadow;
            this.panel3.Controls.Add(this.txtTechMatricul);
            this.panel3.Controls.Add(this.txtTechName);
            this.panel3.Controls.Add(this.label2);
            this.panel3.Controls.Add(this.label3);
            this.panel3.Controls.Add(this.txtTechRepport);
            this.panel3.Controls.Add(this.label16);
            this.panel3.Location = new System.Drawing.Point(7, 6);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(382, 163);
            this.panel3.TabIndex = 2;
            // 
            // txtTechMatricul
            // 
            this.txtTechMatricul.Location = new System.Drawing.Point(207, 23);
            this.txtTechMatricul.Name = "txtTechMatricul";
            this.txtTechMatricul.ReadOnly = true;
            this.txtTechMatricul.Size = new System.Drawing.Size(168, 20);
            this.txtTechMatricul.TabIndex = 1;
            // 
            // txtTechName
            // 
            this.txtTechName.Location = new System.Drawing.Point(207, 58);
            this.txtTechName.Name = "txtTechName";
            this.txtTechName.ReadOnly = true;
            this.txtTechName.Size = new System.Drawing.Size(168, 20);
            this.txtTechName.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(1, 20);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 21);
            this.label2.TabIndex = 0;
            this.label2.Text = "Technicien Matricul :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(1, 55);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(172, 21);
            this.label3.TabIndex = 0;
            this.label3.Text = "Technicien Name :";
            // 
            // txtTechRepport
            // 
            this.txtTechRepport.Location = new System.Drawing.Point(207, 90);
            this.txtTechRepport.Multiline = true;
            this.txtTechRepport.Name = "txtTechRepport";
            this.txtTechRepport.ReadOnly = true;
            this.txtTechRepport.Size = new System.Drawing.Size(168, 56);
            this.txtTechRepport.TabIndex = 1;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(3, 93);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(192, 21);
            this.label16.TabIndex = 0;
            this.label16.Text = "Technicien Repport :";
            // 
            // txtHandWork
            // 
            this.txtHandWork.Location = new System.Drawing.Point(996, 9);
            this.txtHandWork.Name = "txtHandWork";
            this.txtHandWork.ReadOnly = true;
            this.txtHandWork.Size = new System.Drawing.Size(209, 20);
            this.txtHandWork.TabIndex = 1;
            // 
            // txtChangedItemAmt
            // 
            this.txtChangedItemAmt.Location = new System.Drawing.Point(997, 165);
            this.txtChangedItemAmt.Name = "txtChangedItemAmt";
            this.txtChangedItemAmt.ReadOnly = true;
            this.txtChangedItemAmt.Size = new System.Drawing.Size(152, 20);
            this.txtChangedItemAmt.TabIndex = 1;
            // 
            // txtPhoneTrouble
            // 
            this.txtPhoneTrouble.Location = new System.Drawing.Point(587, 219);
            this.txtPhoneTrouble.Name = "txtPhoneTrouble";
            this.txtPhoneTrouble.ReadOnly = true;
            this.txtPhoneTrouble.Size = new System.Drawing.Size(209, 20);
            this.txtPhoneTrouble.TabIndex = 1;
            // 
            // txtDepositedItems
            // 
            this.txtDepositedItems.Location = new System.Drawing.Point(997, 44);
            this.txtDepositedItems.Multiline = true;
            this.txtDepositedItems.Name = "txtDepositedItems";
            this.txtDepositedItems.ReadOnly = true;
            this.txtDepositedItems.Size = new System.Drawing.Size(209, 41);
            this.txtDepositedItems.TabIndex = 1;
            // 
            // txtPhoneState
            // 
            this.txtPhoneState.Location = new System.Drawing.Point(587, 152);
            this.txtPhoneState.Name = "txtPhoneState";
            this.txtPhoneState.ReadOnly = true;
            this.txtPhoneState.Size = new System.Drawing.Size(209, 20);
            this.txtPhoneState.TabIndex = 1;
            // 
            // txtClientAddress
            // 
            this.txtClientAddress.Location = new System.Drawing.Point(587, 12);
            this.txtClientAddress.Name = "txtClientAddress";
            this.txtClientAddress.ReadOnly = true;
            this.txtClientAddress.Size = new System.Drawing.Size(209, 20);
            this.txtClientAddress.TabIndex = 1;
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(539, 323);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(158, 36);
            this.button1.TabIndex = 4;
            this.button1.Text = "Okay";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // txtSerialNumber
            // 
            this.txtSerialNumber.Location = new System.Drawing.Point(587, 79);
            this.txtSerialNumber.Name = "txtSerialNumber";
            this.txtSerialNumber.ReadOnly = true;
            this.txtSerialNumber.Size = new System.Drawing.Size(209, 20);
            this.txtSerialNumber.TabIndex = 1;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.panel4.Controls.Add(this.txtDiagnoAmount);
            this.panel4.Controls.Add(this.txtChangedItems);
            this.panel4.Controls.Add(this.txtEntryDate);
            this.panel4.Controls.Add(this.txtClientPhone);
            this.panel4.Controls.Add(this.txtExitDate);
            this.panel4.Controls.Add(this.txtRDVDate);
            this.panel4.Controls.Add(this.txtSmartphoneMark);
            this.panel4.Controls.Add(this.txtClientNumber);
            this.panel4.Controls.Add(this.panel3);
            this.panel4.Controls.Add(this.txtHandWork);
            this.panel4.Controls.Add(this.txtChangedItemAmt);
            this.panel4.Controls.Add(this.txtPhoneState);
            this.panel4.Controls.Add(this.txtClientAddress);
            this.panel4.Controls.Add(this.txtPhoneTrouble);
            this.panel4.Controls.Add(this.txtDepositedItems);
            this.panel4.Controls.Add(this.txtSerialNumber);
            this.panel4.Controls.Add(this.label15);
            this.panel4.Controls.Add(this.label22);
            this.panel4.Controls.Add(this.label11);
            this.panel4.Controls.Add(this.txtClientNmae);
            this.panel4.Controls.Add(this.label14);
            this.panel4.Controls.Add(this.label20);
            this.panel4.Controls.Add(this.label10);
            this.panel4.Controls.Add(this.label7);
            this.panel4.Controls.Add(this.label13);
            this.panel4.Controls.Add(this.label18);
            this.panel4.Controls.Add(this.label9);
            this.panel4.Controls.Add(this.label4);
            this.panel4.Controls.Add(this.label17);
            this.panel4.Controls.Add(this.label12);
            this.panel4.Controls.Add(this.label8);
            this.panel4.Controls.Add(this.label6);
            this.panel4.Controls.Add(this.label5);
            this.panel4.Location = new System.Drawing.Point(3, 3);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1246, 319);
            this.panel4.TabIndex = 3;
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(814, 9);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(116, 21);
            this.label15.TabIndex = 0;
            this.label15.Text = "HandWork :";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(814, 165);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(134, 42);
            this.label22.TabIndex = 0;
            this.label22.Text = "Changed Item \r\n     Amount:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(405, 152);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(126, 21);
            this.label11.TabIndex = 0;
            this.label11.Text = "Phone State :";
            // 
            // txtClientNmae
            // 
            this.txtClientNmae.Location = new System.Drawing.Point(173, 219);
            this.txtClientNmae.Name = "txtClientNmae";
            this.txtClientNmae.ReadOnly = true;
            this.txtClientNmae.Size = new System.Drawing.Size(209, 20);
            this.txtClientNmae.TabIndex = 1;
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(405, 219);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(144, 21);
            this.label14.TabIndex = 0;
            this.label14.Text = "Phone Trouble:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(814, 44);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(160, 21);
            this.label20.TabIndex = 0;
            this.label20.Text = "Deposited Items :";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(405, 79);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 21);
            this.label10.TabIndex = 0;
            this.label10.Text = "Serial Number:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(405, 11);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(146, 21);
            this.label7.TabIndex = 0;
            this.label7.Text = "Client Address :";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(405, 260);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(182, 21);
            this.label13.TabIndex = 0;
            this.label13.Text = "Diagnostic Amount:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(814, 96);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(141, 21);
            this.label18.TabIndex = 0;
            this.label18.Text = "Changed Items:";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(405, 117);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(118, 21);
            this.label9.TabIndex = 0;
            this.label9.Text = "Entry Date :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(8, 216);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(127, 21);
            this.label4.TabIndex = 0;
            this.label4.Text = "Client Name :";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(814, 219);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(106, 21);
            this.label17.TabIndex = 0;
            this.label17.Text = "Exit Date :";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(405, 184);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(105, 21);
            this.label12.TabIndex = 0;
            this.label12.Text = "RDV Date:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(405, 44);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(176, 21);
            this.label8.TabIndex = 0;
            this.label8.Text = "Smartphone Mark :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(8, 257);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 21);
            this.label6.TabIndex = 0;
            this.label6.Text = "Client Phone :";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Modern No. 20", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(8, 181);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(146, 21);
            this.label5.TabIndex = 0;
            this.label5.Text = "Client Number :";
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(8, 1);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1252, 136);
            this.panel2.TabIndex = 4;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Brush Script Std", 62F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(84, 16);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1108, 96);
            this.label1.TabIndex = 0;
            this.label1.Text = "General View of a Smartphone";
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel4);
            this.panel1.Location = new System.Drawing.Point(8, 134);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1252, 362);
            this.panel1.TabIndex = 5;
            // 
            // test
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1268, 497);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Name = "test";
            this.Text = "test";
            this.panel3.ResumeLayout(false);
            this.panel3.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TextBox txtDiagnoAmount;
        private System.Windows.Forms.TextBox txtChangedItems;
        private System.Windows.Forms.TextBox txtEntryDate;
        private System.Windows.Forms.TextBox txtClientPhone;
        private System.Windows.Forms.TextBox txtExitDate;
        private System.Windows.Forms.TextBox txtRDVDate;
        private System.Windows.Forms.TextBox txtSmartphoneMark;
        private System.Windows.Forms.TextBox txtClientNumber;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.TextBox txtTechMatricul;
        private System.Windows.Forms.TextBox txtTechName;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtTechRepport;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox txtHandWork;
        private System.Windows.Forms.TextBox txtChangedItemAmt;
        private System.Windows.Forms.TextBox txtPhoneTrouble;
        private System.Windows.Forms.TextBox txtDepositedItems;
        private System.Windows.Forms.TextBox txtPhoneState;
        private System.Windows.Forms.TextBox txtClientAddress;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TextBox txtSerialNumber;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtClientNmae;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
    }
}