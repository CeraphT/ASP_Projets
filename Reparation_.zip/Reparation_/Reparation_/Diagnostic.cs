﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Diagnostic : Form
    {
        string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
        private int id;

        public Diagnostic(int id)
        {
            this.id = id;
            InitializeComponent();
        }
        private void button2_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrWhiteSpace(txtRepport.Text))
            {
                MessageBox.Show("Please fill the compulsary textbox (*)!!!");
            }
            else
            {
                try
                {

                    string Rapport_Technicien = txtRepport.Text;
                    string Pieces_Echanges = txtChangeItem.Text;
                    string Montant_Pieces_Echanges = txtAmount.Text;
                    string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
                    string strRequete = "UPDATE TP_Reparation SET Rapport_Technicien = @Rapport_Technicien, Pieces_Echanges = @Pieces_Echanges, Montant_Pieces_Echanges = @Montant_Pieces_Echanges where ID_Reparation = @ID_Reparation ";


                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);

                    oCommand.Parameters.AddWithValue("@Rapport_Technicien", Rapport_Technicien);
                    oCommand.Parameters.AddWithValue("@Pieces_Echanges", Pieces_Echanges);
                    oCommand.Parameters.AddWithValue("@Montant_Pieces_Echanges", Montant_Pieces_Echanges);
                    oCommand.Parameters.AddWithValue("@ID_Reparation", id);

                    oConnection.Open();
                    oCommand.ExecuteNonQuery();
                    oConnection.Close();
                    MessageBox.Show("Diagnostic Done!!!");
                    
                }
                catch (Exception ex)
                {
                    Console.WriteLine("CONNECTION ERROR :" + ex.Message);
                }
                ClearFunction();
                this.Dispose();
            }
        }

        public void ClearFunction()
        {
            txtRepport.Text = null;
            txtChangeItem.Text = null;
            txtAmount.Text = null;
          
        }

        private void txtAmount_TextChanged(object sender, EventArgs e)
        {
            {
                string tString = txtAmount.Text;
                if (tString.Trim() == "") return;
                for (int i = 0; i < tString.Length; i++)
                {
                    if (!char.IsNumber(tString[i]))
                    {
                        MessageBox.Show("Please enter a valid number 'XXXX'");
                        txtAmount.Text = "";
                        return;
                    }
                }
            }
        }
    }
}
