﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Form2 : Form
    {
        private int id;
        public Form2(int id)
        {
            InitializeComponent();
            this.id = id;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if ((string.IsNullOrWhiteSpace(textBox3.Text)) && (string.IsNullOrWhiteSpace(textBox2.Text)))
            {
                MessageBox.Show("Please fill the compulsary textbox (*)!!!");
            }
            else
            {
                try
                {

                    string Nom_client = textBox2.Text;
                    string tel_Client = textBox3.Text;
                    DateTime Rendez_Vous = dateTimePicker2.Value;
                    string Marque_telephone = textBox4.Text;
                    string Numero_serie = Nserie.Text;
                    string pieces_Deposeer = piecesDeposer.Text;
                    string Panne_telephone = panne.Text;
                    double Montant_Diagnostics = double.Parse(AmntDiagno.Text);
                    string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
                    string strRequete = "UPDATE TP_Reparation SET Nom_Client = @Nom_Client, Telephone_Client = @Telephone_Client, Date_Rendez_Vous = @Date_Rendez_Vous, Marque_Smartphone = @Marque_Smartphone, Numero_Serie = @Numero_Serie, Montant_Diagnostic = @Montant_Diagnostic, Pieces_Deposer = @Pieces_Deposer, Panne = @Panne  where ID_Reparation = @ID_Reparation ";


                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                  
                    oCommand.Parameters.AddWithValue("@Nom_Client", Nom_client);
                    oCommand.Parameters.AddWithValue("@Telephone_Client", tel_Client);
                    oCommand.Parameters.AddWithValue("@Marque_Smartphone", Marque_telephone);
                    oCommand.Parameters.AddWithValue("@Numero_Serie", Numero_serie);
                    oCommand.Parameters.AddWithValue("@Date_Rendez_Vous", Rendez_Vous);
                    oCommand.Parameters.AddWithValue("@Panne", Panne_telephone);
                    oCommand.Parameters.AddWithValue("@Montant_Diagnostic", Montant_Diagnostics);
                    oCommand.Parameters.AddWithValue("@Pieces_Deposer", pieces_Deposeer);
                    oCommand.Parameters.AddWithValue("@Date_Entree", DateTime.Now);
                    oCommand.Parameters.AddWithValue("@Etat", 0);
                    oCommand.Parameters.AddWithValue("@ID_Reparation", id);

                    MessageBox.Show("Smartphone Updated!!!");
                    this.Dispose();
                    oConnection.Open();
                    oCommand.ExecuteNonQuery();
                    oConnection.Close();
                }
                catch (Exception ex)
                {
                    Console.WriteLine("CONNECTION ERROR :" + ex.Message);
                }
            }

            }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            {
                string tString = textBox3.Text;
                if (tString.Trim() == "") return;
                for (int i = 0; i < tString.Length; i++)
                {
                    if (!char.IsNumber(tString[i]))
                    {
                        MessageBox.Show("Please enter a valid number");
                        textBox3.Text = "";
                        return;
                    }
                }
            }  
        }
        private void button3_Click(object sender, EventArgs e)
        {
            textBox2.Text = null;
            textBox3.Text = null;
            dateTimePicker2.Text = null;
            textBox4.Text = null;
            Nserie.Text = null;
            piecesDeposer.Text = null;
            panne.Text = null;
            AmntDiagno.Text = null;
        }

        private void Form2_Load(object sender, EventArgs e)
        {

        }
    }
}
