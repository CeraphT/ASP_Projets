﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Manage_Technicien : Form
    {
        string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
        public Manage_Technicien()
        {
            InitializeComponent();
        }
        private void Exitbtn_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var myForm = new Form1();
            myForm.Show();
            LoadFunction();
        }

        private void Loadbtn_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlcon = new SqlConnection(strConnexion)) 
            {
                sqlcon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM TP_Technicien", sqlcon);

                DataTable dataT = new DataTable();
                sqlDa.Fill(dataT);
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dataT;
                sqlcon.Close();
            }
        }

        private void Deletebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Please Select a Row!!");
            }
            else if(dataGridView1.SelectedRows.Count >= 1)
            {
                using (SqlConnection sqlcon = new SqlConnection(strConnexion))
                    for (int i = 0; i < dataGridView1.SelectedRows.Count; i++)
                    {
                       
                        try
                        {
                            DataGridViewRow data = this.dataGridView1.SelectedRows[i];
                            
                            int id = int.Parse(data.Cells["ID_Techinicien"].Value.ToString());
                            string strRequete = "Delete from TP_Technicien where ID_Techinicien=" + id + "";
                            DataGridViewRow dr = dataGridView1.Rows[i];
                            SqlConnection oConnection = new SqlConnection(strConnexion);
                            SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                            oConnection.Open();
                            oCommand.ExecuteNonQuery();
                            oConnection.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Error!!" + ex.ToString());
                        }

                    }
                MessageBox.Show("Technicien Deleted. Please Load your table!!!");
                LoadFunction();
            }
            
        }

        private void Updatebtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Please Select a Row!!");
            }

            if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow data = this.dataGridView1.SelectedRows[0];
                int id = int.Parse(data.Cells["ID_Techinicien"].Value.ToString());
                string strRequete = "SELECT * FROM TP_Technicien where ID_Techinicien = " + id;
                try
                {
                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                    oConnection.Open();
                    SqlDataReader oReader = oCommand.ExecuteReader();
                    int ID_Techinicien;
                    string Nom = "";
                    string Matricule = "";
                    string Telephone = "";
                    string Adresse = "";
                    if (oReader.Read())
                    {
                        ID_Techinicien = oReader.GetInt32(0);
                        Matricule = oReader.GetString(1);
                        Nom = oReader.GetString(2);
                        Telephone = oReader.GetString(3);
                        Adresse = oReader.GetString(4);
                    }

                    oReader.Close();
                    oConnection.Close();

                    Update_Technicien update = new Update_Technicien(id);
                    update.matricule.Text = Matricule;
                    update.nom.Text = Nom;
                    update.telephone.Text = Telephone;
                    update.adresse.Text = Adresse;
                    update.ShowDialog();
                }
                catch (Exception ex)
                {
                    string t = ex.ToString();
                }
            }
             LoadFunction();
        }
        public void LoadFunction()
        {
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(strConnexion))
                {
                    sqlcon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM TP_Technicien", sqlcon);

                    DataTable dataT = new DataTable();
                    sqlDa.Fill(dataT);
                    dataGridView1.AutoGenerateColumns = false;
                    dataGridView1.DataSource = dataT;
                    sqlcon.Close();
                }
            }
            catch (Exception e)
            {
                string t = e.ToString();
            }
        }

        private void Manage_Technicien_Load(object sender, EventArgs e)
        {

        }
    }
}
