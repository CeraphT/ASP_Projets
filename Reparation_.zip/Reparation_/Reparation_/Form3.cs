﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Reparation_
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {

            var myForm = new Manage_Technicien();
            myForm.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {

            var myForm = new Datagrid_Add_Delete_SelectRow_Load_Update();
            myForm.Show();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
    }
}
