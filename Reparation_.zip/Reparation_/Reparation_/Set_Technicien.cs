﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Set_Technicien : Form
    {
       // string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
        private int id;

        public Set_Technicien(int id)
        {
            this.id = id;
            InitializeComponent();
        }

        

        private void Set_Technicien_Load(object sender, EventArgs e)
        {
            string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
            string strRequete = "SELECT ID_Techinicien, Matricule+' : '+Nom as Name FROM TP_Technicien";
            try
            {
                SqlConnection oConnection = new SqlConnection(strConnexion);
                SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                oConnection.Open();
                SqlDataAdapter o = new SqlDataAdapter(oCommand);
                DataTable d = new DataTable();
                o.Fill(d);
                
                comboBox1.DataSource = d;
                comboBox1.DisplayMember = "Name";
                comboBox1.ValueMember = "ID_Techinicien";
                oConnection.Close();
                //view.ShowDialog();
            }
            catch (Exception ex)
            {
                Console.WriteLine("L'erreur suivante a été rencontrée :" + ex.Message);
            }
           
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            string ID = comboBox1.SelectedValue.ToString();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Dispose();
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                int tech = int.Parse(comboBox1.SelectedValue.ToString());
                string set_Technicien = comboBox1.Text;
                string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
                string strRequete = "UPDATE TP_Reparation SET ID_Technicien = @ID_Technicien, Etat = 1 WHERE ID_Reparation =  " + id.ToString();

                SqlConnection oConnection = new SqlConnection(strConnexion);
                SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                oCommand.Parameters.AddWithValue("@ID_Technicien", tech);
                //oCommand.Parameters.AddWithValue("@ID_Techinicien", id);



                this.Dispose();
                oConnection.Open();
                oCommand.ExecuteNonQuery();
                oConnection.Close();
            }
            catch(Exception ex)
            {
                string t = ex.ToString();
            }
            
    }
    } }

