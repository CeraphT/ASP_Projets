﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Reparation_
{
    public partial class Datagrid_Add_Delete_SelectRow_Load_Update : Form
    {
        string strConnexion = "Data Source=localhost; Integrated Security=SSPI;" + "Initial Catalog=BD_Reparation_";
        public Datagrid_Add_Delete_SelectRow_Load_Update()
        {
            InitializeComponent();
        }
        private void btnLoad_Click(object sender, EventArgs e)
        {
            using (SqlConnection sqlcon = new SqlConnection(strConnexion))
            {
                sqlcon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT ID_Reparation, Numero, Nom_Client, Telephone_Client, Marque_Smartphone, Date_Entree, Date_Rendez_Vous, Etat, Nom FROM [TP_Reparation] LEFT JOIN TP_Technicien ON [TP_Reparation].ID_Technicien = TP_Technicien.ID_Techinicien", sqlcon);
                DataTable dataT = new DataTable();
                sqlDa.Fill(dataT);
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dataT;
                sqlcon.Close();
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            var myForm = new Smartphone();
            myForm.Show();
            LoadFunction();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count <= 0)
            {
                MessageBox.Show("Please Select a Row!!");
            }
            using (SqlConnection sqlcon = new SqlConnection(strConnexion))
                for (int i = 0; i < dataGridView1.SelectedRows.Count; i++)
                {
                    DataGridViewRow data = this.dataGridView1.SelectedRows[i];

                    // this is in order to collect the id of reparation and will redirect us to the users infos for delete option
                    int id = int.Parse(data.Cells["ID_Reparation"].Value.ToString());
                    string strRequete = "Delete from TP_Reparation where ID_Reparation=" + id + "";
                    DataGridViewRow dr = dataGridView1.Rows[i];
                    try
                    {
                        SqlConnection oConnection = new SqlConnection(strConnexion);
                        SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                        oConnection.Open();
                        oCommand.ExecuteNonQuery();
                        oConnection.Close();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error!!" + ex.ToString());
                    }

                }
            LoadFunction();
            MessageBox.Show("Smartphone Deleted!!!");
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Please Select a Row!!");
            }

            else if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow data = this.dataGridView1.SelectedRows[0];
                int id = int.Parse(data.Cells["ID_Reparation"].Value.ToString());
                string strRequete = "SELECT * FROM TP_Reparation where ID_Reparation = " + id;
                try
                {
                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                    oConnection.Open();
                    SqlDataReader oReader = oCommand.ExecuteReader();

                    
                    int ID_Technicien;
                    string Numero;
                    string Nom_Client;
                    string Telephone_Client;
                    string Adresse_Client;
                    string Marque_Smartphone;
                    string Numero_Serie;
                    DateTime Date_Entree;
                    byte Etat;
                    DateTime Date_rendez_vous;
                    string Panne;
                    double Montant_Diagnostic = 0;
                    double Main_Oeuvre;
                    string Rapport_Technicien;
                    string Pieces_Deposer;
                    string Pieces_Echanges;
                    double Montant_Pieces_Echanges;
                    DateTime Date_Sortie;

                    if (oReader.Read())
                    {
                        id = oReader.GetInt32(0);
                        if(!oReader.IsDBNull(1))
                        {
                            ID_Technicien = oReader.GetInt32(1);
                        }
                       
                        Numero = oReader.GetString(2);
                        Nom_Client = oReader.GetString(3);
                        Telephone_Client = oReader.GetString(4);
                        if (!oReader.IsDBNull(5))
                        {
                            Adresse_Client = oReader.GetString(5);
                        }

                        Marque_Smartphone = oReader.GetString(6);
                        Numero_Serie = oReader.GetString(7);
                        Date_Entree = oReader.GetDateTime(8);
                        Etat = oReader.GetByte(9);
                        Date_rendez_vous = oReader.GetDateTime(10);
                        Panne = oReader.GetString(11);
                        if (!oReader.IsDBNull(12))
                        {
                            Montant_Diagnostic = oReader.GetDouble(12);
                        }
                        if (!oReader.IsDBNull(13))
                        {
                            Main_Oeuvre = oReader.GetDouble(13);
                        }
                        if (!oReader.IsDBNull(14))
                        {
                            Rapport_Technicien = oReader.GetString(14);
                        }
                        Pieces_Deposer = oReader.GetString(15);
                        if (!oReader.IsDBNull(16))
                        {
                            Pieces_Echanges = oReader.GetString(16);
                        }
                        if (!oReader.IsDBNull(17))
                        {
                            Montant_Pieces_Echanges = oReader.GetDouble(17);
                        }
                        
                        if (!oReader.IsDBNull(18))
                        {
                            Date_Sortie = oReader.GetDateTime(18);
                        }
           
                        Form2 update = new Form2(id);
                        update.textBox2.Text = Nom_Client;
                        update.textBox3.Text = Telephone_Client;
                        update.textBox4.Text = Marque_Smartphone;
                        update.Nserie.Text = Numero_Serie;
                        update.AmntDiagno.Text = Montant_Diagnostic.ToString();
                        update.piecesDeposer.Text = Pieces_Deposer;
                        update.panne.Text = Panne;
                        update.ShowDialog();

                    }

                    oReader.Close();
                    oConnection.Close();

                   
                }
                catch (Exception ex)
                {
                    string t = ex.ToString();
                }
            }
            LoadFunction();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Dispose();
        }


        public void LoadFunction()
        {

            using (SqlConnection sqlcon = new SqlConnection(strConnexion))
            {
                sqlcon.Open();
                SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM TP_Reparation", sqlcon);

                DataTable dataT = new DataTable();
                sqlDa.Fill(dataT);
                dataGridView1.AutoGenerateColumns = false;
                dataGridView1.DataSource = dataT;
                sqlcon.Close();
            }
        }

        private void SetTech_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count !=1 )
            {
                MessageBox.Show("Please Select a Row!!");
            }

            else if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow data = this.dataGridView1.SelectedRows[0];
                int id = int.Parse(data.Cells["ID_Reparation"].Value.ToString());
                Set_Technicien view = new Set_Technicien(id);
                view.ShowDialog();
               
            }
            LoadFunction();
        }

        private void DiagnoBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Please Select a Row!!");
            }

            else if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow data = this.dataGridView1.SelectedRows[0];
                int id = int.Parse(data.Cells["ID_Reparation"].Value.ToString());
                string strRequete = "SELECT * FROM TP_Reparation where ID_Reparation = " + id;
                try
                {
                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                    oConnection.Open();
                    SqlDataReader oReader = oCommand.ExecuteReader();


                    int ID_Technicien;
                    string Numero;
                    string Nom_Client;
                    string Telephone_Client;
                    string Adresse_Client;
                    string Marque_Smartphone;
                    string Numero_Serie;
                    DateTime Date_Entree;
                    byte Etat;
                    DateTime Date_rendez_vous;
                    string Panne;
                    double Montant_Diagnostic = 0;
                    double Main_Oeuvre;
                    string Rapport_Technicien = "";
                    string Pieces_Deposer;
                    string Pieces_Echanges = "";
                    double Montant_Pieces_Echanges = 0;
                    DateTime? Date_Sortie = null;

                    if (oReader.Read())
                    {
                        id = oReader.GetInt32(0);
                        if (!oReader.IsDBNull(1))
                        {
                            ID_Technicien = oReader.GetInt32(1);
                        }

                        Numero = oReader.GetString(2);
                        Nom_Client = oReader.GetString(3);
                        Telephone_Client = oReader.GetString(4);
                        if (!oReader.IsDBNull(5))
                        {
                            Adresse_Client = oReader.GetString(5);
                        }

                        Marque_Smartphone = oReader.GetString(6);
                        Numero_Serie = oReader.GetString(7);
                        Date_Entree = oReader.GetDateTime(8);
                        Etat = oReader.GetByte(9);
                        Date_rendez_vous = oReader.GetDateTime(10);
                        Panne = oReader.GetString(11);
                        if (!oReader.IsDBNull(12))
                        {
                            Montant_Diagnostic = oReader.GetDouble(12);
                        }
                        if (!oReader.IsDBNull(13))
                        {
                            Main_Oeuvre = oReader.GetDouble(13);
                        }
                        if (!oReader.IsDBNull(14))
                        {
                            Rapport_Technicien = oReader.GetString(14);
                        }
                        Pieces_Deposer = oReader.GetString(15);
                        if (!oReader.IsDBNull(16))
                        {
                            Pieces_Echanges = oReader.GetString(16);
                        }
                        if (!oReader.IsDBNull(17))
                        {
                            Montant_Pieces_Echanges = oReader.GetDouble(17);
                        }

                        if (!oReader.IsDBNull(18))
                        {
                            Date_Sortie = oReader.GetDateTime(18);
                        }

                        Diagnostic diagno = new Diagnostic(id);
                        diagno.txtRepport.Text = Rapport_Technicien;
                        diagno.txtChangeItem.Text = Pieces_Echanges;
                        diagno.txtAmount.Text = Montant_Pieces_Echanges.ToString();
                        diagno.ShowDialog();
                        LoadFunction();


                    }

                    oReader.Close();
                    oConnection.Close();


                }
                catch (Exception ex)
                {
                    string t = ex.ToString();
                }
                LoadFunction();
            }

        }

        private void consultBtn_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count != 1)
            {
                MessageBox.Show("Please Select a Row!!");
            }

            else if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow data = this.dataGridView1.SelectedRows[0];
                int id = int.Parse(data.Cells["ID_Reparation"].Value.ToString());
                string strRequete = "SELECT * FROM TP_Reparation, TP_Technicien where ID_Reparation = " + id;
                try
                {
                    SqlConnection oConnection = new SqlConnection(strConnexion);
                    SqlCommand oCommand = new SqlCommand(strRequete, oConnection);
                    oConnection.Open();
                    SqlDataReader oReader = oCommand.ExecuteReader();


                    int ID_Technicien;
                    string Numero;
                    string Nom_Client;
                    string Telephone_Client;
                    string Adresse_Client = "" ;
                    string Marque_Smartphone;
                    string Numero_Serie;
                    DateTime Date_Entree;
                    byte Etat;
                    DateTime Date_rendez_vous;
                    string Panne;
                    double Montant_Diagnostic = 0;
                    double Main_Oeuvre = 0 ;
                    string Rapport_Technicien;
                    string Pieces_Deposer = "";
                    string Pieces_Echanges = "";
                    double Montant_Pieces_Echanges = 0;
                    DateTime? Date_Sortie = null ;

                    // Technicien informations
                    string Matricule = "";
                    string Nom = "";
                    string Telephone;
                    string Adresse;

                    if (oReader.Read())
                    {
                        id = oReader.GetInt32(0);
                        if (!oReader.IsDBNull(1))
                        {
                            ID_Technicien = oReader.GetInt32(1);
                        }

                        Numero = oReader.GetString(2);
                        Nom_Client = oReader.GetString(3);
                        Telephone_Client = oReader.GetString(4);
                        if (!oReader.IsDBNull(5))
                        {
                            Adresse_Client = oReader.GetString(5);
                        }

                        Marque_Smartphone = oReader.GetString(6);
                        Numero_Serie = oReader.GetString(7);
                        Date_Entree = oReader.GetDateTime(8);
                        Etat = oReader.GetByte(9);
                        Date_rendez_vous = oReader.GetDateTime(10);
                        Panne = oReader.GetString(11);
                        if (!oReader.IsDBNull(12))
                        {
                            Montant_Diagnostic = oReader.GetDouble(12);
                        }
                        if (!oReader.IsDBNull(13))
                        {
                            Main_Oeuvre = oReader.GetDouble(13);
                        }
                        if (!oReader.IsDBNull(14))
                        {
                            Rapport_Technicien = oReader.GetString(14);
                        }
                        Pieces_Deposer = oReader.GetString(15);
                        if (!oReader.IsDBNull(16))
                        {
                            Pieces_Echanges = oReader.GetString(16);
                        }
                        if (!oReader.IsDBNull(17))
                        {
                            Montant_Pieces_Echanges = oReader.GetDouble(17);
                        }

                        if (!oReader.IsDBNull(18))
                        {
                            Date_Sortie = oReader.GetDateTime(18);
                        }

                        ConsultReparationView update = new ConsultReparationView(id);
                        update.txtClientNumber.Text = Numero;
                        update.txtClientNmae.Text = Nom_Client;
                        update.txtClientPhone.Text = Telephone_Client;
                        update.txtClientAddress.Text = Adresse_Client;
                        update.txtSmartphoneMark.Text = Marque_Smartphone;
                        update.txtSerialNumber.Text = Numero_Serie;
                        update.txtEntryDate.Text = Date_Entree.ToString();
                        update.txtPhoneState.Text = Etat.ToString();
                        update.txtRDVDate.Text = Date_rendez_vous.ToString();
                        update.txtPhoneTrouble.Text = Panne.ToString();
                        update.txtDiagnoAmount.Text = Montant_Diagnostic.ToString();
                        update.txtHandWork.Text = Main_Oeuvre.ToString();
                        update.txtDepositedItems.Text = Pieces_Deposer;
                        update.txtChangedItems.Text = Pieces_Echanges.ToString();
                        update.txtChangedItemAmt.Text = Montant_Pieces_Echanges.ToString();
                        update.txtExitDate.Text = (Date_Sortie == null ? "" : Date_Sortie.ToString());
                        update.txtTechMatricul.Text = Matricule.ToString();
                        update.txtTechName.Text = Nom.ToString();

                        update.ShowDialog();

                    }

                    oReader.Close();
                    oConnection.Close();


                }
                catch (Exception ex)
                {
                    string t = ex.ToString();
                }
            }
        }
    }
}

       
    

