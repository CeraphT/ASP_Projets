﻿namespace Reparation_
{
    partial class Datagrid_Add_Delete_SelectRow_Load_Update
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.consultBtn = new System.Windows.Forms.Button();
            this.DiagnoBtn = new System.Windows.Forms.Button();
            this.SetTech = new System.Windows.Forms.Button();
            this.btnLoad = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnAdd = new System.Windows.Forms.Button();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label1 = new System.Windows.Forms.Label();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.ID_Reparation = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.ID_Technicien = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Number = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nom_Client = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Nom = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Telephone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Smartphone = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date_Entree = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Date_RDV = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Etat = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel1.Controls.Add(this.consultBtn);
            this.panel1.Controls.Add(this.DiagnoBtn);
            this.panel1.Controls.Add(this.SetTech);
            this.panel1.Controls.Add(this.btnLoad);
            this.panel1.Controls.Add(this.btnDelete);
            this.panel1.Controls.Add(this.btnUpdate);
            this.panel1.Controls.Add(this.btnAdd);
            this.panel1.Location = new System.Drawing.Point(4, 126);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(195, 371);
            this.panel1.TabIndex = 0;
            // 
            // consultBtn
            // 
            this.consultBtn.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold);
            this.consultBtn.Location = new System.Drawing.Point(8, 312);
            this.consultBtn.Name = "consultBtn";
            this.consultBtn.Size = new System.Drawing.Size(171, 42);
            this.consultBtn.TabIndex = 5;
            this.consultBtn.Text = "Consult";
            this.consultBtn.UseVisualStyleBackColor = true;
            this.consultBtn.Click += new System.EventHandler(this.consultBtn_Click);
            // 
            // DiagnoBtn
            // 
            this.DiagnoBtn.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold);
            this.DiagnoBtn.Location = new System.Drawing.Point(8, 264);
            this.DiagnoBtn.Name = "DiagnoBtn";
            this.DiagnoBtn.Size = new System.Drawing.Size(171, 42);
            this.DiagnoBtn.TabIndex = 5;
            this.DiagnoBtn.Text = "Diagnostics";
            this.DiagnoBtn.UseVisualStyleBackColor = true;
            this.DiagnoBtn.Click += new System.EventHandler(this.DiagnoBtn_Click);
            // 
            // SetTech
            // 
            this.SetTech.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold);
            this.SetTech.Location = new System.Drawing.Point(8, 216);
            this.SetTech.Name = "SetTech";
            this.SetTech.Size = new System.Drawing.Size(171, 42);
            this.SetTech.TabIndex = 4;
            this.SetTech.Text = "Set Technicien";
            this.SetTech.UseVisualStyleBackColor = true;
            this.SetTech.Click += new System.EventHandler(this.SetTech_Click);
            // 
            // btnLoad
            // 
            this.btnLoad.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLoad.Location = new System.Drawing.Point(8, 16);
            this.btnLoad.Name = "btnLoad";
            this.btnLoad.Size = new System.Drawing.Size(171, 44);
            this.btnLoad.TabIndex = 3;
            this.btnLoad.Text = "Load";
            this.btnLoad.UseVisualStyleBackColor = true;
            this.btnLoad.Click += new System.EventHandler(this.btnLoad_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.Location = new System.Drawing.Point(8, 166);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(171, 44);
            this.btnDelete.TabIndex = 2;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // btnUpdate
            // 
            this.btnUpdate.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnUpdate.Location = new System.Drawing.Point(8, 116);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(171, 44);
            this.btnUpdate.TabIndex = 1;
            this.btnUpdate.Text = "Update";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Modern No. 20", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(8, 66);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(171, 44);
            this.btnAdd.TabIndex = 0;
            this.btnAdd.Text = "Add";
            this.btnAdd.UseVisualStyleBackColor = true;
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.SystemColors.Highlight;
            this.panel2.Controls.Add(this.label1);
            this.panel2.Location = new System.Drawing.Point(4, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1252, 136);
            this.panel2.TabIndex = 1;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Brush Script Std", 72F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(-11, 11);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1284, 112);
            this.label1.TabIndex = 0;
            this.label1.Text = "Manage Smartphone MENU";
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToOrderColumns = true;
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.ButtonHighlight;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.ID_Reparation,
            this.ID_Technicien,
            this.Number,
            this.Nom_Client,
            this.Nom,
            this.Telephone,
            this.Smartphone,
            this.Date_Entree,
            this.Date_RDV,
            this.Etat});
            this.dataGridView1.Location = new System.Drawing.Point(205, 142);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridView1.Size = new System.Drawing.Size(1051, 355);
            this.dataGridView1.TabIndex = 2;
            // 
            // ID_Reparation
            // 
            this.ID_Reparation.DataPropertyName = "ID_Reparation";
            this.ID_Reparation.Frozen = true;
            this.ID_Reparation.HeaderText = "id";
            this.ID_Reparation.Name = "ID_Reparation";
            this.ID_Reparation.ReadOnly = true;
            this.ID_Reparation.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.ID_Reparation.Visible = false;
            // 
            // ID_Technicien
            // 
            this.ID_Technicien.DataPropertyName = "ID_Technicien";
            this.ID_Technicien.Frozen = true;
            this.ID_Technicien.HeaderText = "ID Technicien";
            this.ID_Technicien.Name = "ID_Technicien";
            this.ID_Technicien.ReadOnly = true;
            this.ID_Technicien.Visible = false;
            // 
            // Number
            // 
            this.Number.DataPropertyName = "Numero";
            this.Number.Frozen = true;
            this.Number.HeaderText = "Number";
            this.Number.Name = "Number";
            this.Number.ReadOnly = true;
            this.Number.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Number.Width = 80;
            // 
            // Nom_Client
            // 
            this.Nom_Client.DataPropertyName = "Nom_Client";
            this.Nom_Client.Frozen = true;
            this.Nom_Client.HeaderText = "Client Name";
            this.Nom_Client.Name = "Nom_Client";
            this.Nom_Client.ReadOnly = true;
            this.Nom_Client.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Nom_Client.Width = 140;
            // 
            // Nom
            // 
            this.Nom.DataPropertyName = "Nom";
            this.Nom.Frozen = true;
            this.Nom.HeaderText = "Technicien Name";
            this.Nom.Name = "Nom";
            this.Nom.ReadOnly = true;
            this.Nom.Resizable = System.Windows.Forms.DataGridViewTriState.True;
            this.Nom.Width = 200;
            // 
            // Telephone
            // 
            this.Telephone.DataPropertyName = "Telephone_Client";
            this.Telephone.Frozen = true;
            this.Telephone.HeaderText = "Phone Number";
            this.Telephone.Name = "Telephone";
            this.Telephone.ReadOnly = true;
            this.Telephone.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            // 
            // Smartphone
            // 
            this.Smartphone.DataPropertyName = "Marque_Smartphone";
            this.Smartphone.Frozen = true;
            this.Smartphone.HeaderText = "Smartphone";
            this.Smartphone.Name = "Smartphone";
            this.Smartphone.ReadOnly = true;
            this.Smartphone.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Smartphone.Width = 120;
            // 
            // Date_Entree
            // 
            this.Date_Entree.DataPropertyName = "Date_Entree";
            this.Date_Entree.Frozen = true;
            this.Date_Entree.HeaderText = "Entry Date";
            this.Date_Entree.Name = "Date_Entree";
            this.Date_Entree.ReadOnly = true;
            this.Date_Entree.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Date_Entree.Width = 150;
            // 
            // Date_RDV
            // 
            this.Date_RDV.DataPropertyName = "Date_Rendez_Vous";
            this.Date_RDV.Frozen = true;
            this.Date_RDV.HeaderText = "RDV Date";
            this.Date_RDV.Name = "Date_RDV";
            this.Date_RDV.ReadOnly = true;
            this.Date_RDV.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Date_RDV.Width = 150;
            // 
            // Etat
            // 
            this.Etat.DataPropertyName = "Etat";
            this.Etat.Frozen = true;
            this.Etat.HeaderText = "State";
            this.Etat.Name = "Etat";
            this.Etat.ReadOnly = true;
            this.Etat.Resizable = System.Windows.Forms.DataGridViewTriState.False;
            this.Etat.Width = 80;
            // 
            // Datagrid_Add_Delete_SelectRow_Load_Update
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1257, 500);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.HelpButton = true;
            this.MaximizeBox = false;
            this.Name = "Datagrid_Add_Delete_SelectRow_Load_Update";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "MANAGE SMARTPHONES";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button btnLoad;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button SetTech;
        private System.Windows.Forms.DataGridViewTextBoxColumn Etat;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date_RDV;
        private System.Windows.Forms.DataGridViewTextBoxColumn Date_Entree;
        private System.Windows.Forms.DataGridViewTextBoxColumn Smartphone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Telephone;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nom;
        private System.Windows.Forms.DataGridViewTextBoxColumn Nom_Client;
        private System.Windows.Forms.DataGridViewTextBoxColumn Number;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Technicien;
        private System.Windows.Forms.DataGridViewTextBoxColumn ID_Reparation;
        private System.Windows.Forms.Button DiagnoBtn;
        private System.Windows.Forms.Button consultBtn;
    }
}